<?php

include_once "conexion.php";

$id = null;
$nombre_completo    = $_POST["nombre_completo"];
$email              = $_POST["email"];
$telefono           = $_POST["telefono"];
$contraseña         = $_POST["contraseña"];
$id_usuario         = $_POST["id_usuario"];



if($resultado == TRUE)
  header('Location: popup.html '); 
?>



<?php

include("../conexion.php");

$nombre_completo = $_POST["nombre_completo"];
$email = $_POST["email"];
$telefono = $_POST["telefono"];
$contraseña = $_POST["contraseña"];
$id = $_POST["id"];

// la inyección SQL utilizando los statements
$sentencia = $base_de_datos->prepare("UPDATE `tabla_registro` SET nombre_completo = ?, email = ?, telefono = ?, contraseña = ? WHERE id = ?");
$sentencia->bind_param("ssssi", $nombre_completo, $email, $telefono, $contraseña, $id);
$resultado = $sentencia->execute();

if ($resultado === TRUE) {
    header('Location: ../listarPersonas.php'); // Corregí el error en la dirección de redirección
    exit(); // Terminar la ejecución del script después de la redirección:p
} else {
    echo "Error al actualizar los datos: " . $base_de_datos->error;
}

// Cerrar la conexión a la base de datos
$sentencia->close();
$base_de_datos->close();

?>
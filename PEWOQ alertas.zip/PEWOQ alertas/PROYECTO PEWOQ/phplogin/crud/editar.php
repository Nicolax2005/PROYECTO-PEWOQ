<?php
// Verifica si se ha enviado el parámetro "id"
if (!isset($_GET["id"])) {
    exit();
}

// Incluye el archivo de conexión a la base de datos
include("../conexion.php");

// Prepara la consulta SQL para obtener los datos del usuario a editar
$sentencia = "SELECT * FROM tabla_registro WHERE id = ?";
if ($stmt = mysqli_prepare($base_de_datos, $sentencia)) {
    // Vincula los parámetros y ejecuta la consulta
    mysqli_stmt_bind_param($stmt, "i", $_GET["id"]);
    mysqli_stmt_execute($stmt);

    // Obtiene el resultado de la consulta
    $result = mysqli_stmt_get_result($stmt);

    // Verifica si se encontró un usuario con el ID proporcionado
    if ($persona = mysqli_fetch_assoc($result)) {
        // Liberar el resultado y cerrar la consulta preparada
        mysqli_free_result($result);
        mysqli_stmt_close($stmt);
    } else {
        // Si no se encontró ningún usuario con el ID proporcionado, redirige o muestra un mensaje de error
        exit("Usuario no encontrado.");
    }
} else {
    // Si hay algún error en la preparación de la consulta, muestra un mensaje de error
    exit("Error en la consulta.");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Editar Usuario</title>
</head>
<body>
  
  <h1>Editar Usuario</h1>
  <form action="/PROYECTO PEWOQ/phplogin/crud/guardarDatosEditados.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
    <div>
      <label for="nombre_completo">Nombre Completo:</label>
      <input type="text" name="nombre_completo" id="nombre_completo" value="<?php echo $persona['nombre_completo']; ?>">
    </div>
    <div>
      <label for="email">Correo:</label>
      <input type="email" name="email" id="email" value="<?php echo $persona['email']; ?>">
    </div>
    <div>
      <label for="telefono">Teléfono:</label>
      <input type="text" name="telefono" id="telefono" value="<?php echo $persona['telefono']; ?>">
    </div>
    <div>
      <label for="contraseña">Contraseña:</label>
      <!-- no se muestra la contraseña en texto plano -->
      <input type="password" name="contraseña" id="contraseña" value="<?php echo $persona['contraseña']; ?>">
    </div>
    <div>
      <input type="submit" value="Guardar Cambios">
    </div>
  </form>
</body>
</html>
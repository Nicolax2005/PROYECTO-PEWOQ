document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("contactForm");

    form.addEventListener("submit", function(event) {
        event.preventDefault(); // Evitar que el formulario se envíe automáticamente

        // Validar campos
        const nombre = document.getElementById("nombre").value;
        const apellido = document.getElementById("apellido").value;
        const email = document.getElementById("email").value;
        const telefono = document.getElementById("telefono").value;
        const mensaje = document.getElementById("mensaje").value;

        if (nombre.trim() === "" || apellido.trim() === "" || email.trim() === "" || mensaje.trim() === "") {
            mostrarAlerta("Por favor, completa todos los campos.", "error");
            return;
        }

        if (!validarTelefono(telefono)) {
            mostrarAlerta("Por favor, ingresa solo números en el campo de teléfono.", "error");
            return;
        }

        // Si todos los campos están completos, enviar el formulario
        mostrarAlerta("Formulario enviado correctamente.", "success");
        form.reset(); // Limpiar el formulario
    });

    // Función para validar que el teléfono solo contenga números
    function validarTelefono(telefono) {
        const re = /^[0-9]+$/;
        return re.test(telefono);
    }

    // Función para mostrar una alerta
    function mostrarAlerta(mensaje, tipo) {
        swal({
            title: mensaje,
            icon: tipo,
            button: "Aceptar",
            closeOnClickOutside: false,
            closeOnEsc: false,
        });
    }
});